/**
 * @file main.c
 * @author Prof. Dr. David Buzatto
 * @brief Modelo para desenvolvimento de exercícios criativos usando a engine
 * de jogos Raylib (https://www.raylib.com/).
 * 
 * @copyright Copyright (c) 2024
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include <raylib.h>

void desenharPoligono( int x, int y, int lados, int raio, Color cor );

int main( void ) {

    /*-----------------------------------------------------
     * A lógica inicial do seu programa deve vir aqui:
     *     - declaração de variáveis;
     *     - entrada de dados;
     *     - processamentos adicionais.
     ----------------------------------------------------*/
    // VLAVAAV
    Color cores[7] = { RED, ORANGE, YELLOW, GREEN, BLUE, DARKBLUE, VIOLET };
    
    // ativa a suavização (antialiasing)
    SetConfigFlags( FLAG_MSAA_4X_HINT );

    // cria uma janela de 800 pixels de largura por 800 de altura
    InitWindow( 800, 800, "Polígonos" );

    // configura a quantidade de quatros por segundo da engine
    SetTargetFPS( 60 );    

    // enquanto não é sinalizado que a janela deve ser fechada
    while ( !WindowShouldClose() ) {

        // inicia o processo de desenho
        BeginDrawing();

        // limpa a tela usando uma cor
        ClearBackground( WHITE );

        /*----------------------------------------------------------------------
         * A lógica do seu desenho deve vir aqui.
         ---------------------------------------------------------------------*/

        int xc = GetScreenWidth() / 2;
        int yc = GetScreenHeight() / 2;

        for ( int i = 0; i < 7; i++ ) {
            desenharPoligono( xc, yc, 3+i, 200 + 10 * i, cores[i] );
        }

        /*----------------------------------------------------------------------
         * A lógica do seu desenho deve terminar na linha acima.
         ---------------------------------------------------------------------*/

        // termina o desenho
        EndDrawing();

    }

    // fecha a janela
    CloseWindow();
    return 0;

}

void desenharPoligono( int x, int y, int lados, int raio, Color cor ) {

    float anguloInterno = 2 * PI / lados;   // radianos!
    float anguloAtual = 0;

    int xAnt = 0;
    int yAnt = 0;

    for ( int i = 0; i <= lados; i++ ) {

        int xv = x + raio * cosf( anguloAtual );
        int yv = y + raio * sinf( anguloAtual );
        anguloAtual += anguloInterno;

        if ( i != 0 ) {
            DrawLine( xv, yv, xAnt, yAnt, cor );
        }

        xAnt = xv;
        yAnt = yv;

    }

}
