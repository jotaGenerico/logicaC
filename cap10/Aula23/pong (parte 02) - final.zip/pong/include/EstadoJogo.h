#pragma once

typedef enum EstadoJogo {
    PARADO,
    JOGANDO
} EstadoJogo;