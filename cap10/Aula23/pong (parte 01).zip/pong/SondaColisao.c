#include "SondaColisao.h"
#include "raylib.h"

void atualizarSondaColisao( SondaColisao *sonda ) {

}

void desenharSondaColisao( SondaColisao *sonda ) {
    DrawCircleV( sonda->pos, sonda->raio, sonda->cor );
}