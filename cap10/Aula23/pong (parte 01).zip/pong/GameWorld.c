/**
 * @file GameWorld.h
 * @author Prof. Dr. David Buzatto
 * @brief GameWorld implementation.
 * 
 * @copyright Copyright (c) 2024
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "GameWorld.h"
#include "ResourceManager.h"

#include "Bola.h"
#include "Jogador.h"

#include "raylib.h"
//#include "raymath.h"
//#define RAYGUI_IMPLEMENTATION    // to use raygui, comment these three lines.
//#include "raygui.h"              // other compilation units must only include
//#undef RAYGUI_IMPLEMENTATION     // raygui.h

/**
 * @brief Creates a dinamically allocated GameWorld struct instance.
 */
GameWorld* createGameWorld( void ) {

    GameWorld *gw = (GameWorld*) malloc( sizeof( GameWorld ) );

    gw->bola = (Bola){
        .pos = {
            .x = GetScreenWidth() / 2,
            .y = GetScreenHeight() / 2
        },
        .vel = {
            .x = 300,
            .y = 300
        },
        .raio = 10,
        .cor = WHITE,
        .quantidadeSondas = 12,
        .distanciaSondas = 8
    };

    Bola *bola = &gw->bola;

    bola->sondas = (SondaColisao*) malloc( bola->quantidadeSondas * sizeof(SondaColisao) );
    float angulo = 0.0f;
    float incrementoAngulo = 360.0f / bola->quantidadeSondas;
    angulo -= incrementoAngulo;

    Color coresSondas[4] = { BLUE, ORANGE, GREEN, RED };

    for ( int i = 0; i < bola->quantidadeSondas; i++ ) {
        bola->sondas[i] = (SondaColisao){
            .pos = {
                .x = bola->pos.x + bola->distanciaSondas * cosf( DEG2RAD * angulo ),
                .y = bola->pos.y + bola->distanciaSondas * sinf( DEG2RAD * angulo ),
            },
            .raio = 2,
            .cor = coresSondas[i/3]
        };
        angulo += incrementoAngulo;
    }

    int margem = 50;
    int largura = 20;
    int altura = 100;

    gw->jogador1 = (Jogador){
        .ret = {
            .x = margem,
            .y = GetScreenHeight() / 2 - altura / 2,
            .width = largura,
            .height = altura
        },
        .velY = 0,
        .cor = WHITE 
    };

    gw->jogador2 = (Jogador){
        .ret = {
            .x = GetScreenWidth() - largura - margem,
            .y = GetScreenHeight() / 2 - altura / 2,
            .width = largura,
            .height = altura
        },
        .velY = 0,
        .cor = WHITE 
    };

    return gw;

}

/**
 * @brief Destroys a GameWindow object and its dependecies.
 */
void destroyGameWorld( GameWorld *gw ) {
    free( gw->bola.sondas );
    free( gw );
}

/**
 * @brief Reads user input and updates the state of the game.
 */
void inputAndUpdateGameWorld( GameWorld *gw ) {

    float delta = GetFrameTime();
    int velJogador = (int) ( 300 * delta );

    if ( IsKeyDown( KEY_W ) ) {
        gw->jogador1.velY = -velJogador;
    } else if ( IsKeyDown( KEY_S ) ) {
        gw->jogador1.velY = velJogador;
    } else {
        gw->jogador1.velY = 0;
    }

    if ( IsKeyDown( KEY_UP ) ) {
        gw->jogador2.velY = -velJogador;
    } else if ( IsKeyDown( KEY_DOWN ) ) {
        gw->jogador2.velY = velJogador;
    } else {
        gw->jogador2.velY = 0;
    }

    atualizarBola( &gw->bola );
    atualizarJogador( &gw->jogador1 );
    atualizarJogador( &gw->jogador2 );

    switch ( checarColisaoBolaJogador( &gw->bola, &gw->jogador1 ) ) {
        case DIREITA:
        case ESQUERDA:
            gw->bola.vel.x *= -1;
            break;
        case CIMA:
        case BAIXO:
            gw->bola.vel.y *= -1;
            break;
        case NENHUM:
        default:
            break;
    }

    switch ( checarColisaoBolaJogador( &gw->bola, &gw->jogador2 ) ) {
        case DIREITA:
        case ESQUERDA:
            gw->bola.vel.x *= -1;
            break;
        case CIMA:
        case BAIXO:
            gw->bola.vel.y *= -1;
            break;
        case NENHUM:
        default:
            break;
    }

}

/**
 * @brief Draws the state of the game.
 */
void drawGameWorld( GameWorld *gw ) {

    BeginDrawing();
    ClearBackground( BLACK );

    desenharBola( &gw->bola );
    desenharJogador( &gw->jogador1 );
    desenharJogador( &gw->jogador2 );

    EndDrawing();

}