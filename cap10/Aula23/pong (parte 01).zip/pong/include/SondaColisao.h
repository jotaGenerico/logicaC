#pragma once

#include "raygui.h"

typedef struct SondaColisao {
    Vector2 pos;
    int raio;
    Color cor;
} SondaColisao;

void atualizarSondaColisao( SondaColisao *sonda );
void desenharSondaColisao( SondaColisao *sonda );