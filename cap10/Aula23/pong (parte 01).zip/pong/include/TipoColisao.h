#pragma once

typedef enum TipoColisao {
    DIREITA,
    ESQUERDA,
    CIMA,
    BAIXO,
    NENHUM
} TipoColisao;