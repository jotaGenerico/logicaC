#pragma once

#include "raylib.h"

typedef struct Jogador {
    Rectangle ret;
    int velY;
    Color cor;
} Jogador;

void atualizarJogador( Jogador *jogador );
void desenharJogador( Jogador *jogador );