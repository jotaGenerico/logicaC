/* 
 * Arquivo: EntradaSaidaPadraoFormatadosOlaMundo.c
 * Autor: Prof. Dr. David Buzatto
 */
 
#include <stdio.h>
#include <stdlib.h>

int main( void ) {
    
    // comentários de uma linha iniciam com // (duas barras)
    
    // a função printf direciona o texto inserido (entre aspas duplas)
    // para a saída padrão
    printf( "Ola mundo!!" );
    
    return 0;
    
}