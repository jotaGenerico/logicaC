#pragma once

void exercicioCriativo01( const char *titulo );
void exercicioCriativo02( const char *titulo );
void exercicioCriativo03( const char *titulo );
void exercicioCriativo04( const char *titulo );
void exercicioCriativo05( const char *titulo );
void exercicioCriativo06( const char *titulo );
void exercicioCriativo07( const char *titulo );
void exercicioCriativo08( const char *titulo );
void exercicioCriativo09( const char *titulo );
void exercicioCriativo10( const char *titulo );
void exercicioCriativo11( const char *titulo );
void exercicioCriativo12( const char *titulo );
void exercicioCriativo13( const char *titulo );
void exercicioCriativo14( const char *titulo );
void exercicioCriativo15( const char *titulo );
void exercicioCriativo16( const char *titulo );
void exercicioCriativo17( const char *titulo );
void exercicioCriativo18( const char *titulo );
void exercicioCriativo19( const char *titulo );
void exercicioCriativo20( const char *titulo );