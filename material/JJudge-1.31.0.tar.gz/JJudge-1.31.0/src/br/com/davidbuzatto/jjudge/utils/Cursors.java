package br.com.davidbuzatto.jjudge.utils;

import java.awt.Cursor;

/**
 *
 * @author Prof. Dr. David Buzatto
 */
public class Cursors {
    
    public static Cursor HAND_CURSOR = new Cursor( Cursor.HAND_CURSOR );
    public static Cursor DEFAULT_CURSOR = new Cursor( Cursor.DEFAULT_CURSOR );
    
}
