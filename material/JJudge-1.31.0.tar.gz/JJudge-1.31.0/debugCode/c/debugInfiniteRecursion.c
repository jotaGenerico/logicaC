#include <stdio.h>
#include <stdlib.h>

void f() {
    f();
}

int main() {
    
    f();

    return 0;

}
