#include <iostream>

using namespace std;

int main() {

    cout << "a a a\n";
    cout << "a a a\n";
    cout << "x\ta\ta\n\n";
    cout << "a\ta\ta\n\n";
    cout << "\ta\ta";

    return 0;

}
