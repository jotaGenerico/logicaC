
public class debugApproveComplexOutput {

    public static void main( String[] args ) {

        System.out.print( "a a a\n" );
        System.out.print( "a a a\n" );
        System.out.print( "a\ta\ta\n\n" );
        System.out.print( "a\ta\ta\n\n" );
        System.out.print( "\ta\ta" );

    }

}
