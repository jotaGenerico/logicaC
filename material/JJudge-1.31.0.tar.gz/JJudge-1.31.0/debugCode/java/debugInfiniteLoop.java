
public class debugInfiniteLoop {

    public static void main( String[] args ) {
        f();
    }

    public static void f() {
        while ( true ) {
        }
    }
    
}
