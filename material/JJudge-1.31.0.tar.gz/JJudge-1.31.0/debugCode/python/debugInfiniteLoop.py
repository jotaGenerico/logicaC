# -*- coding: utf-8 -*-

def f():
    while True:
        print( "" )

f()
