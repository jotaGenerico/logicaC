#include <stdio.h>
#include <stdlib.h>

int main() {

    printf( "   *\n" );
    printf( "  ***\n" );
    printf( " *****\n" );
    printf( "*******" );

    return 0;

}
